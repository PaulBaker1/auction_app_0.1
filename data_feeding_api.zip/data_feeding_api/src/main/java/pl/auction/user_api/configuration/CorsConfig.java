package pl.auction.user_api.configuration;public class CorsConfig {
}
